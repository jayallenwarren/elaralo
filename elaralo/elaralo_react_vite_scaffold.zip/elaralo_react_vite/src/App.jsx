import './styles.css'

export default function App(){
  return (
    <div className="container">
      <h1>1) Plan catalog & included minutes (per rolling 30-day window)</h1>
      <div className="table-scroll">
        <table className="table">
          <thead>
            <tr>
              <th>Plan</th>
              <th className="ta-center">Price</th>
              <th>Modes available</th>
              <th className="ta-center">Per-session cap</th>
              <th className="ta-right">Included minutes / 30 days</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Trial <small>(free; replaces Guest/Visitor)</small></td>
              <td className="ta-center">Free</td>
              <td>Friend only</td>
              <td className="ta-center">10 min</td>
              <td className="ta-right">10 min total</td>
            </tr>
            <tr>
              <td>Member</td>
              <td className="ta-center">Paid</td>
              <td>Friend, Romantic,<br/>Intimate (18+)</td>
              <td className="ta-center">Friend: 15 min • Romantic: 30 min • Intimate: 60 min</td>
              <td className="ta-right">105 min total (pooled)</td>
            </tr>
          </tbody>
        </table>
      </div>
      <h2 style={{marginTop:'1.5rem'}}>Test API</h2>
      <p><a className="btn btn-primary" href="#" onClick={health}>Ping backend</a> <span id="status"></span></p>
    </div>
  )
}

async function health(){
  try{
    const res = await fetch(import.meta.env.VITE_API_BASE || 'http://localhost:8000/health');
    const data = await res.json();
    document.getElementById('status').textContent = data.ok ? 'OK' : 'Error';
  }catch(e){
    document.getElementById('status').textContent = 'Error';
  }
}
