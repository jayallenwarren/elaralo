# Elaralo React/Vite Scaffold
## Setup
npm install
npm run dev
# Backend base URL
cp .env.example .env
# .env -> VITE_API_BASE=http://localhost:8000
