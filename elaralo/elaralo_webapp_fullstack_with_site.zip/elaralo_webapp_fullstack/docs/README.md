# Elaralo Web App Fullstack

Run locally:

pip install -r backend/requirements.txt
uvicorn backend.app:app --reload
